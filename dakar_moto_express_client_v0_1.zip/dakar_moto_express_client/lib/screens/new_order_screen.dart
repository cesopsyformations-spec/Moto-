import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../models/delivery_order.dart';

class NewOrderScreen extends StatefulWidget {
  const NewOrderScreen({super.key, required this.onOrderCreated});

  final ValueChanged<DeliveryOrder> onOrderCreated;

  @override
  State<NewOrderScreen> createState() => _NewOrderScreenState();
}

class _NewOrderScreenState extends State<NewOrderScreen> {
  final _formKey = GlobalKey<FormState>();
  final _pickupController = TextEditingController();
  final _dropoffController = TextEditingController();
  final _recipientController = TextEditingController();
  final _phoneController = TextEditingController();
  final _packageController = TextEditingController();
  final _distanceController = TextEditingController(text: '5');

  String _category = 'Colis';
  bool _showEstimate = false;

  double get _distance => double.tryParse(_distanceController.text.trim()) ?? 0;
  int get _price => AppConfig.calculateDemoFare(_distance);

  @override
  void dispose() {
    _pickupController.dispose();
    _dropoffController.dispose();
    _recipientController.dispose();
    _phoneController.dispose();
    _packageController.dispose();
    _distanceController.dispose();
    super.dispose();
  }

  String? _required(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'Ce champ est obligatoire';
    }
    return null;
  }

  void _calculateEstimate() {
    if (!_formKey.currentState!.validate()) return;
    if (_distance <= 0 || _distance > 100) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Saisissez une distance entre 0,1 et 100 km.')),
      );
      return;
    }
    setState(() => _showEstimate = true);
  }

  void _confirmOrder() {
    final order = DeliveryOrder(
      reference: 'DMX-${DateTime.now().millisecondsSinceEpoch}',
      pickupAddress: _pickupController.text.trim(),
      dropoffAddress: _dropoffController.text.trim(),
      recipientName: _recipientController.text.trim(),
      recipientPhone: _phoneController.text.trim(),
      category: _category,
      packageDescription: _packageController.text.trim().isEmpty
          ? 'Non précisé'
          : _packageController.text.trim(),
      distanceKm: _distance,
      estimatedPrice: _price,
      createdAt: DateTime.now(),
    );
    widget.onOrderCreated(order);
    setState(() => _showEstimate = false);
    _formKey.currentState?.reset();
    _pickupController.clear();
    _dropoffController.clear();
    _recipientController.clear();
    _phoneController.clear();
    _packageController.clear();
    _distanceController.text = '5';
    setState(() => _category = 'Colis');
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Nouvelle livraison',
                style: TextStyle(
                  color: AppColors.navy,
                  fontSize: 25,
                  fontWeight: FontWeight.w800,
                ),
              ),
              const SizedBox(height: 5),
              const Text(
                'Renseignez les informations de votre envoi.',
                style: TextStyle(color: AppColors.muted),
              ),
              const SizedBox(height: 22),
              _sectionTitle('Trajet', Icons.route_rounded),
              const SizedBox(height: 12),
              TextFormField(
                controller: _pickupController,
                validator: _required,
                decoration: const InputDecoration(
                  labelText: 'Adresse de récupération',
                  hintText: 'Ex. : Plateau, Dakar',
                  prefixIcon: Icon(Icons.trip_origin, color: AppColors.green),
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _dropoffController,
                validator: _required,
                decoration: const InputDecoration(
                  labelText: 'Adresse de destination',
                  hintText: 'Ex. : Centre-ville, Rufisque',
                  prefixIcon: Icon(Icons.location_on_outlined, color: AppColors.orange),
                ),
              ),
              const SizedBox(height: 22),
              _sectionTitle('Détails du destinataire', Icons.person_outline),
              const SizedBox(height: 12),
              TextFormField(
                controller: _recipientController,
                validator: _required,
                decoration: const InputDecoration(
                  labelText: 'Nom du destinataire',
                  prefixIcon: Icon(Icons.person_outline),
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _phoneController,
                validator: (value) {
                  if (value == null || value.trim().isEmpty) {
                    return 'Le téléphone du destinataire est obligatoire';
                  }
                  if (value.trim().length < 8) return 'Numéro trop court';
                  return null;
                },
                keyboardType: TextInputType.phone,
                decoration: const InputDecoration(
                  labelText: 'Téléphone du destinataire',
                  hintText: '+221 77 000 00 00',
                  prefixIcon: Icon(Icons.phone_outlined),
                ),
              ),
              const SizedBox(height: 22),
              _sectionTitle('Informations sur le colis', Icons.inventory_2_outlined),
              const SizedBox(height: 12),
              DropdownButtonFormField<String>(
                value: _category,
                decoration: const InputDecoration(
                  labelText: 'Type de livraison',
                  prefixIcon: Icon(Icons.category_outlined),
                ),
                items: const [
                  DropdownMenuItem(value: 'Colis', child: Text('Colis')),
                  DropdownMenuItem(value: 'Documents', child: Text('Documents')),
                  DropdownMenuItem(value: 'Repas', child: Text('Repas')),
                  DropdownMenuItem(value: 'Courses', child: Text('Courses')),
                  DropdownMenuItem(value: 'Marchandises', child: Text('Marchandises')),
                ],
                onChanged: (value) {
                  if (value != null) setState(() => _category = value);
                },
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _packageController,
                decoration: const InputDecoration(
                  labelText: 'Description du colis (facultatif)',
                  hintText: 'Ex. : petit carton, enveloppe...',
                  prefixIcon: Icon(Icons.inventory_outlined),
                ),
              ),
              const SizedBox(height: 12),
              TextFormField(
                controller: _distanceController,
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                decoration: const InputDecoration(
                  labelText: 'Distance estimée en kilomètres',
                  hintText: 'Ex. : 5',
                  prefixIcon: Icon(Icons.straighten_rounded),
                  helperText: 'Valeur provisoire saisie pour la démonstration.',
                ),
              ),
              const SizedBox(height: 20),
              OutlinedButton.icon(
                onPressed: _calculateEstimate,
                icon: const Icon(Icons.calculate_outlined),
                label: const Text('Calculer le prix estimatif'),
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.navy,
                  minimumSize: const Size.fromHeight(52),
                  side: const BorderSide(color: AppColors.navy),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(14),
                  ),
                ),
              ),
              if (_showEstimate) ...[
                const SizedBox(height: 18),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: AppColors.navy,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Estimation de démonstration',
                        style: TextStyle(color: Colors.white70),
                      ),
                      const SizedBox(height: 7),
                      Text(
                        AppConfig.formatFcfa(_price),
                        style: const TextStyle(
                          color: AppColors.orange,
                          fontSize: 27,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        '${_distance.toStringAsFixed(1)} km • $_category',
                        style: const TextStyle(color: Colors.white),
                      ),
                      const SizedBox(height: 12),
                      const Text(
                        'Ce tarif utilise des paramètres de test. Le tarif réel sera calculé par le serveur après intégration de la cartographie et validation de la grille tarifaire.',
                        style: TextStyle(color: Colors.white70, fontSize: 11),
                      ),
                      const SizedBox(height: 16),
                      ElevatedButton(
                        onPressed: _confirmOrder,
                        child: const Text('Confirmer la commande de test'),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _sectionTitle(String title, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: AppColors.orange),
        const SizedBox(width: 9),
        Text(
          title,
          style: const TextStyle(
            color: AppColors.navy,
            fontWeight: FontWeight.w800,
            fontSize: 17,
          ),
        ),
      ],
    );
  }
}
