import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../widgets/brand_logo.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.fromLTRB(20, 20, 20, 28),
        children: [
          const Text(
            'Mon profil',
            style: TextStyle(
              color: AppColors.navy,
              fontSize: 25,
              fontWeight: FontWeight.w800,
            ),
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              color: AppColors.navy,
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: Colors.white,
                  child: Icon(Icons.person, color: AppColors.navy, size: 32),
                ),
                SizedBox(width: 13),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Client invité',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 17,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'Compte de démonstration',
                        style: TextStyle(color: Colors.white70, fontSize: 12),
                      ),
                    ],
                  ),
                ),
                Icon(Icons.edit_outlined, color: Colors.white),
              ],
            ),
          ),
          const SizedBox(height: 20),
          _menuItem(Icons.person_outline, 'Informations personnelles'),
          _menuItem(Icons.location_on_outlined, 'Mes adresses'),
          _menuItem(Icons.account_balance_wallet_outlined, 'Moyens de paiement'),
          _menuItem(Icons.notifications_none, 'Notifications'),
          _menuItem(Icons.help_outline, 'Aide et assistance'),
          _menuItem(Icons.privacy_tip_outlined, 'Confidentialité'),
          _menuItem(Icons.info_outline, 'À propos de Dakar Moto Express'),
          const SizedBox(height: 24),
          const Center(child: BrandLogo(compact: true)),
          const SizedBox(height: 8),
          const Center(
            child: Text(
              'Version prototype 0.1.0',
              style: TextStyle(color: AppColors.muted, fontSize: 11),
            ),
          ),
        ],
      ),
    );
  }

  Widget _menuItem(IconData icon, String title) {
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: AppColors.border),
      ),
      child: ListTile(
        leading: Icon(icon, color: AppColors.orange),
        title: Text(
          title,
          style: const TextStyle(
            color: AppColors.navy,
            fontWeight: FontWeight.w600,
            fontSize: 14,
          ),
        ),
        trailing: const Icon(Icons.chevron_right, color: AppColors.muted),
        onTap: () {},
      ),
    );
  }
}
