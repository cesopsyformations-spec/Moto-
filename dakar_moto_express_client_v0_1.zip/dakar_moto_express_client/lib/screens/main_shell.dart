import 'package:flutter/material.dart';
import '../config/app_config.dart';
import '../models/delivery_order.dart';
import 'home_screen.dart';
import 'new_order_screen.dart';
import 'history_screen.dart';
import 'profile_screen.dart';
import 'tracking_screen.dart';

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _selectedIndex = 0;
  final List<DeliveryOrder> _orders = [];

  void _addOrder(DeliveryOrder order) {
    setState(() {
      _orders.insert(0, order);
      _selectedIndex = 2;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Votre commande a été enregistrée sur cet appareil.'),
      ),
    );
  }

  void _openTracking(DeliveryOrder order) {
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => TrackingScreen(order: order),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomeScreen(
        onNewOrder: () => setState(() => _selectedIndex = 1),
      ),
      NewOrderScreen(onOrderCreated: _addOrder),
      HistoryScreen(
        orders: _orders,
        onTrack: _openTracking,
        onNewOrder: () => setState(() => _selectedIndex = 1),
      ),
      const ProfileScreen(),
    ];

    return Scaffold(
      body: IndexedStack(
        index: _selectedIndex,
        children: pages,
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _selectedIndex,
        onDestinationSelected: (index) {
          setState(() => _selectedIndex = index);
        },
        backgroundColor: Colors.white,
        indicatorColor: AppColors.orange.withOpacity(0.14),
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home_rounded),
            label: 'Accueil',
          ),
          NavigationDestination(
            icon: Icon(Icons.add_box_outlined),
            selectedIcon: Icon(Icons.add_box_rounded),
            label: 'Commander',
          ),
          NavigationDestination(
            icon: Icon(Icons.receipt_long_outlined),
            selectedIcon: Icon(Icons.receipt_long_rounded),
            label: 'Historique',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline_rounded),
            selectedIcon: Icon(Icons.person_rounded),
            label: 'Profil',
          ),
        ],
      ),
    );
  }
}
