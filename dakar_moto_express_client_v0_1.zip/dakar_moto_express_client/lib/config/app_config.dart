import 'package:flutter/material.dart';

class AppColors {
  static const navy = Color(0xFF0B2250);
  static const orange = Color(0xFFFF7A00);
  static const background = Color(0xFFF5F7FB);
  static const border = Color(0xFFE2E7F0);
  static const muted = Color(0xFF68758A);
  static const green = Color(0xFF16834A);
}

class AppConfig {
  // TARIFS DE DÉMONSTRATION UNIQUEMENT.
  // À remplacer par les tarifs approuvés avant tout lancement commercial.
  static const int demoBaseFare = 1000;
  static const int demoPricePerKm = 200;
  static const int demoMinimumFare = 1500;

  static int calculateDemoFare(double distanceKm) {
    final calculated = demoBaseFare + (distanceKm * demoPricePerKm).round();
    final roundedToFifty = ((calculated + 49) ~/ 50) * 50;
    return roundedToFifty < demoMinimumFare
        ? demoMinimumFare
        : roundedToFifty;
  }

  static String formatFcfa(int amount) {
    final digits = amount.toString();
    final buffer = StringBuffer();
    for (var i = 0; i < digits.length; i++) {
      buffer.write(digits[i]);
      final remaining = digits.length - i - 1;
      if (remaining > 0 && remaining % 3 == 0) {
        buffer.write(' ');
      }
    }
    return '${buffer.toString()} FCFA';
  }
}
