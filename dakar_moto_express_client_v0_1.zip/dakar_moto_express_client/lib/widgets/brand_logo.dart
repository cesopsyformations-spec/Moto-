import 'package:flutter/material.dart';
import '../config/app_config.dart';

class BrandLogo extends StatelessWidget {
  const BrandLogo({
    super.key,
    this.compact = false,
    this.light = false,
  });

  final bool compact;
  final bool light;

  @override
  Widget build(BuildContext context) {
    final textColor = light ? Colors.white : AppColors.navy;

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: compact ? 42 : 52,
          height: compact ? 42 : 52,
          decoration: BoxDecoration(
            color: AppColors.orange,
            borderRadius: BorderRadius.circular(15),
          ),
          child: Icon(
            Icons.two_wheeler_rounded,
            color: Colors.white,
            size: compact ? 26 : 33,
          ),
        ),
        const SizedBox(width: 10),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Dakar Moto',
              style: TextStyle(
                color: textColor,
                fontSize: compact ? 15 : 19,
                fontWeight: FontWeight.w800,
                height: 1.0,
              ),
            ),
            Text(
              'Express',
              style: TextStyle(
                color: AppColors.orange,
                fontSize: compact ? 14 : 18,
                fontWeight: FontWeight.w800,
                height: 1.1,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
