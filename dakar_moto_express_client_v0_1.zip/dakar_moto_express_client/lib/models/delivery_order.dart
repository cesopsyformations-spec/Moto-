class DeliveryOrder {
  const DeliveryOrder({
    required this.reference,
    required this.pickupAddress,
    required this.dropoffAddress,
    required this.recipientName,
    required this.recipientPhone,
    required this.category,
    required this.packageDescription,
    required this.distanceKm,
    required this.estimatedPrice,
    required this.createdAt,
    this.status = 'Commande confirmée',
  });

  final String reference;
  final String pickupAddress;
  final String dropoffAddress;
  final String recipientName;
  final String recipientPhone;
  final String category;
  final String packageDescription;
  final double distanceKm;
  final int estimatedPrice;
  final DateTime createdAt;
  final String status;
}
