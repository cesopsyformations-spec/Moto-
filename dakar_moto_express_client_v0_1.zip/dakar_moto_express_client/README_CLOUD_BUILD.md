# Obtenir l'APK de Dakar Moto Express sans installer Flutter

Le projet est compilé sur les serveurs GitHub Actions. Tu n'as pas besoin d'installer Flutter ou Android Studio sur ton téléphone ou ton ordinateur pour cette compilation.

## Ce qu'il faut

- Un compte GitHub gratuit : https://github.com/
- Une connexion Internet.
- L'archive `dakar_moto_express_client_v0_1.zip` fournie.
- Le fichier `build-apk.yml` fourni.

## Étape A — Créer un dépôt GitHub

1. Ouvre https://github.com/new et connecte-toi.
2. Donne au dépôt le nom `dakar-moto-express-client`.
3. Choisis Public ou Private.
4. Crée le dépôt.

## Étape B — Ajouter le code source

1. Dans le dépôt, choisis **Add file** puis **Upload files**.
2. Envoie uniquement `dakar_moto_express_client_v0_1.zip` à la racine du dépôt.
3. Valide avec **Commit changes**.

## Étape C — Ajouter le workflow de compilation

1. Dans le dépôt, choisis **Add file** puis **Create new file**.
2. Dans le nom du fichier, écris exactement :
   `.github/workflows/build-apk.yml`
3. Ouvre le fichier `build-apk.yml` fourni dans ce kit, copie tout son contenu et colle-le dans l'éditeur GitHub.
4. Clique sur **Commit changes**.

Le workflow détecte l'archive ZIP, l'extrait et compile le projet Android automatiquement.

## Étape D — Télécharger l'APK

1. Ouvre l'onglet **Actions** du dépôt.
2. Sélectionne **Build Dakar Moto Express APK**.
3. Attends que l'exécution se termine avec une coche verte.
4. Ouvre l'exécution terminée.
5. Dans **Artifacts**, télécharge `dakar-moto-express-android-debug`.
6. Décompresse l'archive téléchargée : tu trouveras `app-debug.apk`.
7. Sur ton Tecno Camon 20, ouvre le fichier APK.
8. Si Android le demande, autorise l'installation depuis cette source, puis installe l'application.

## Important

- L'APK est une version **debug de test**, installable sur Android, pas une version de production pour Google Play.
- Le workflow exécute aussi le test Flutter. Si un test échoue, la compilation s'arrête et il faudra corriger l'erreur.
- La version actuelle est un prototype local. Elle ne transmet pas encore de vraies commandes à des livreurs, n'a pas de GPS réel, de comptes en ligne ni de paiements.
- Les commandes sont conservées uniquement en mémoire pendant l'exécution de l'application.
- Les tarifs actuels sont des valeurs de démonstration.
- Ne publie jamais de clés secrètes ni de données personnelles dans un dépôt public.
- GitHub Actions peut être soumis à des quotas ou paramètres du compte GitHub.

## Contenu du workflow

Le fichier `build-apk.yml` de cette archive est celui à copier dans `.github/workflows/build-apk.yml`.
