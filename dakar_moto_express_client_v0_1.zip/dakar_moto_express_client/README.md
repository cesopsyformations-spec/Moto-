# Dakar Moto Express — Application client (prototype Flutter)

Cette version est un prototype local de l'application client.

## Fonctionnalités incluses

- Accueil et catégories de livraison
- Formulaire de nouvelle commande
- Estimation locale de démonstration
- Confirmation locale d'une commande
- Historique conservé uniquement en mémoire pendant l'exécution
- Écran de suivi avec emplacement réservé à la future carte GPS
- Profil de démonstration

## Ce qui n'est PAS encore connecté

- Comptes clients réels et authentification par SMS
- Serveur/API et base de données
- Google Maps et géolocalisation réelle
- Attribution à un livreur partenaire
- Notifications push
- Wave, Orange Money et paiements réels
- Stockage permanent des commandes

Les prix configurés dans `lib/config/app_config.dart` sont des valeurs de test uniquement.

## Prérequis

Installer :
1. Flutter SDK (canal stable)
2. Android Studio
3. Android SDK et les outils de plateforme
4. Un émulateur Android ou un téléphone Android avec le mode développeur et le débogage USB activés

Vérifier l'installation :

```bash
flutter doctor
```

## Installation

1. Décompresser le dossier.
2. Installer Flutter SDK et Android Studio.
3. Ouvrir un terminal dans le dossier `dakar_moto_express_client`.
4. Générer les dossiers de plateforme Android/iOS (ils ne sont pas inclus dans cette archive source) :

```bash
flutter create --platforms=android .
```

5. Télécharger les dépendances :

```bash
flutter pub get
```

6. Vérifier les appareils disponibles :

```bash
flutter devices
```

7. Lancer l'application :

```bash
flutter run
```

## Générer un APK de test

```bash
flutter build apk --debug
```

Le fichier APK de test est généralement créé ici :

```text
build/app/outputs/flutter-apk/app-debug.apk
```

Pour un APK de production, il faudra configurer la signature Android avant la diffusion.

## Organisation des fichiers

```text
lib/
  main.dart
  app.dart
  config/
    app_config.dart
  models/
    delivery_order.dart
  screens/
    main_shell.dart
    home_screen.dart
    new_order_screen.dart
    history_screen.dart
    tracking_screen.dart
    profile_screen.dart
  widgets/
    brand_logo.dart
test/
  widget_test.dart
```

## Modifier les tarifs de démonstration

Ouvrir `lib/config/app_config.dart`.

Les constantes suivantes sont des valeurs fictives de développement :

```dart
static const int demoBaseFare = 1000;
static const int demoPricePerKm = 200;
static const int demoMinimumFare = 1500;
```

Ne pas utiliser ces valeurs pour facturer de vrais clients sans validation commerciale.

## Prochaine étape technique

Créer un backend sécurisé et une API. L'application client devra ensuite envoyer les commandes au serveur, qui calculera le prix officiel, enregistrera les données et recherchera les livreurs partenaires disponibles.
