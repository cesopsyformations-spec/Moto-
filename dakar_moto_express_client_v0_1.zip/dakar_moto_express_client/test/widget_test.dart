import 'package:flutter_test/flutter_test.dart';
import 'package:dakar_moto_express_client/app.dart';

void main() {
  testWidgets('affiche la marque et la navigation principale', (tester) async {
    await tester.pumpWidget(const DakarMotoExpressApp());

    // Le logo apparaît sur l'accueil et dans le profil (IndexedStack).
    expect(find.text('Dakar Moto'), findsWidgets);
    expect(find.text('Accueil'), findsOneWidget);
    expect(find.text('Commander'), findsOneWidget);
    expect(find.text('Historique'), findsOneWidget);
    expect(find.text('Profil'), findsOneWidget);
  });
}
